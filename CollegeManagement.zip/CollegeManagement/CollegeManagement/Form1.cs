﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeManagement
{
    public partial class Form1 : Form
    {
        string connectionString =
            @"Data Source=(local);Initial Catalog=Demo;Integrated Security=True;";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btncheck_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtStudentId.Text, out int studentId))
            {
                lblResult.Text = "Enter Student Id";
                return;
            }

            SqlConnection connection = new SqlConnection(connectionString);
            {
                try
                {
                    connection.Open();
                    string query = "SELECT COUNT(*) FROM Students WHERE StudentId = @StudentId";
                    SqlCommand cmd = new SqlCommand(query, connection);
                    cmd.Parameters.AddWithValue("@StudentId", studentId);
                    int count = Convert.ToInt32(cmd.ExecuteScalar());

                    if (count > 0)
                    {
                        lblResult.Text = "Student already registered";
                    }

                    else
                    {
                        lblResult.Text = "Student is not registered";
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Database error: " + ex.Message);

                }
            }
        }

        private void btnregister_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtStudentId.Text, out int studentId))
            {
                lblResult.Text = "Please enter a valid Student ID";
                return;
            }

            if (!int.TryParse(txtAge.Text, out int age))
            {
                lblResult.Text = "Please enter a valid age";
                return;
            }
            string name = txtName.Text;
            string email = txtEmail.Text;

            if (name == "" || email == "")
            {
                lblResult.Text = "Please complete all fields";
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string checkQuery =
                        "SELECT COUNT(*) FROM Students WHERE StudentId = @StudentId";
                    SqlCommand checkCmd =
                        new SqlCommand(checkQuery, connection);
                    checkCmd.Parameters.AddWithValue("@StudentId", studentId);
                    int count =
                        Convert.ToInt32(checkCmd.ExecuteScalar());
                    if (count > 0)
                    {
                        lblResult.Text = "Student is already registered";
                        return;
                    }

                    string insertQuery =
                        @"INSERT INTO Students (StudentId, Name, Email, Age)
                        VALUES (@StudentId, @Name, @Email, @Age)";
                    SqlCommand cmd = new SqlCommand(insertQuery, connection);

                    cmd.Parameters.AddWithValue("@StudentId", studentId);
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Email", email);
                    cmd.Parameters.AddWithValue("@Age", age);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        lblResult.Text = "Student registered successfully";
                    }
                }
                catch (Exception ex) 
                {
                    MessageBox.Show("Database error: " + ex.Message);
                }
            }
        }
    }
}
