﻿namespace STUDENT_APP
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Student_Id = new System.Windows.Forms.Label();
            this.Name = new System.Windows.Forms.Label();
            this.Email = new System.Windows.Forms.Label();
            this.Age = new System.Windows.Forms.Label();
            this.Check_Student = new System.Windows.Forms.Button();
            this.Register_Student = new System.Windows.Forms.Button();
            this.Id_Box = new System.Windows.Forms.TextBox();
            this.Name_box = new System.Windows.Forms.TextBox();
            this.Email_Box = new System.Windows.Forms.TextBox();
            this.Age_Box = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(102, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Student_Id
            // 
            this.Student_Id.AutoSize = true;
            this.Student_Id.Location = new System.Drawing.Point(99, 44);
            this.Student_Id.Name = "Student_Id";
            this.Student_Id.Size = new System.Drawing.Size(62, 13);
            this.Student_Id.TabIndex = 0;
            this.Student_Id.Text = "Student Id: ";
            this.Student_Id.Click += new System.EventHandler(this.label1_Click);
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(99, 77);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(41, 13);
            this.Name.TabIndex = 1;
            this.Name.Text = "Name: ";
            this.Name.Click += new System.EventHandler(this.Name_Click);
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(102, 118);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(38, 13);
            this.Email.TabIndex = 2;
            this.Email.Text = "Email: ";
            // 
            // Age
            // 
            this.Age.AutoSize = true;
            this.Age.Location = new System.Drawing.Point(102, 152);
            this.Age.Name = "Age";
            this.Age.Size = new System.Drawing.Size(32, 13);
            this.Age.TabIndex = 3;
            this.Age.Text = "Age: ";
            // 
            // Check_Student
            // 
            this.Check_Student.Location = new System.Drawing.Point(65, 203);
            this.Check_Student.Name = "Check_Student";
            this.Check_Student.Size = new System.Drawing.Size(75, 23);
            this.Check_Student.TabIndex = 4;
            this.Check_Student.Text = "Check Student";
            this.Check_Student.UseVisualStyleBackColor = true;
            this.Check_Student.Click += new System.EventHandler(this.button1_Click);
            // 
            // Register_Student
            // 
            this.Register_Student.Location = new System.Drawing.Point(203, 203);
            this.Register_Student.Name = "Register_Student";
            this.Register_Student.Size = new System.Drawing.Size(75, 23);
            this.Register_Student.TabIndex = 5;
            this.Register_Student.Text = "Register Student";
            this.Register_Student.UseVisualStyleBackColor = true;
            // 
            // Id_Box
            // 
            this.Id_Box.Location = new System.Drawing.Point(191, 41);
            this.Id_Box.Name = "Id_Box";
            this.Id_Box.Size = new System.Drawing.Size(100, 20);
            this.Id_Box.TabIndex = 6;
            this.Id_Box.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // Name_box
            // 
            this.Name_box.Location = new System.Drawing.Point(191, 77);
            this.Name_box.Name = "Name_box";
            this.Name_box.Size = new System.Drawing.Size(100, 20);
            this.Name_box.TabIndex = 7;
            // 
            // Email_Box
            // 
            this.Email_Box.Location = new System.Drawing.Point(191, 118);
            this.Email_Box.Name = "Email_Box";
            this.Email_Box.Size = new System.Drawing.Size(100, 20);
            this.Email_Box.TabIndex = 8;
            // 
            // Age_Box
            // 
            this.Age_Box.Location = new System.Drawing.Point(191, 152);
            this.Age_Box.Name = "Age_Box";
            this.Age_Box.Size = new System.Drawing.Size(100, 20);
            this.Age_Box.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 562);
            this.Controls.Add(this.Age_Box);
            this.Controls.Add(this.Email_Box);
            this.Controls.Add(this.Name_box);
            this.Controls.Add(this.Id_Box);
            this.Controls.Add(this.Register_Student);
            this.Controls.Add(this.Check_Student);
            this.Controls.Add(this.Age);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.Student_Id);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Student_Id;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.Label Age;
        private System.Windows.Forms.Button Check_Student;
        private System.Windows.Forms.Button Register_Student;
        private System.Windows.Forms.TextBox Id_Box;
        private System.Windows.Forms.TextBox Name_box;
        private System.Windows.Forms.TextBox Email_Box;
        private System.Windows.Forms.TextBox Age_Box;
    }
}

