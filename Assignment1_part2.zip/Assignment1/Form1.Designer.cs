﻿namespace Assignment1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            name = new Label();
            label3 = new Label();
            age = new Label();
            email = new Label();
            txtStudentId = new TextBox();
            txtName = new TextBox();
            txtEmail = new TextBox();
            txtAge = new TextBox();
            btnCheck = new Button();
            btnRegister = new Button();
            result = new Label();
            lblResult = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(86, 80);
            label1.Name = "label1";
            label1.Size = new Size(79, 20);
            label1.TabIndex = 0;
            label1.Text = "Student ID";
            //label1.Click += label1_Click;
            // 
            // name
            // 
            name.AutoSize = true;
            name.Location = new Point(86, 130);
            name.Name = "name";
            name.Size = new Size(49, 20);
            name.TabIndex = 1;
            name.Text = "Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(115, 214);
            label3.Name = "label3";
            label3.Size = new Size(0, 20);
            label3.TabIndex = 2;
            // 
            // age
            // 
            age.AutoSize = true;
            age.Location = new Point(86, 224);
            age.Name = "age";
            age.Size = new Size(36, 20);
            age.TabIndex = 3;
            age.Text = "Age";
            age.Click += label4_Click;
            // 
            // email
            // 
            email.AutoSize = true;
            email.Location = new Point(86, 176);
            email.Name = "email";
            email.Size = new Size(46, 20);
            email.TabIndex = 4;
            email.Text = "Email";
            // 
            // txtStudentId
            // 
            txtStudentId.Location = new Point(189, 73);
            txtStudentId.Name = "txtStudentId";
            txtStudentId.Size = new Size(125, 27);
            txtStudentId.TabIndex = 5;
            txtStudentId.TextChanged += textBox1_TextChanged;
            // 
            // txtName
            // 
            txtName.Location = new Point(189, 130);
            txtName.Name = "txtName";
            txtName.Size = new Size(125, 27);
            txtName.TabIndex = 6;
            txtName.TextChanged += textBox2_TextChanged;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(189, 176);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(125, 27);
            txtEmail.TabIndex = 7;
            txtEmail.TextChanged += textBox3_TextChanged;
            // 
            // txtAge
            // 
            txtAge.Location = new Point(189, 224);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(125, 27);
            txtAge.TabIndex = 8;
            // 
            // btnCheck
            // 
            btnCheck.Location = new Point(189, 279);
            btnCheck.Name = "btnCheck";
            btnCheck.Size = new Size(125, 29);
            btnCheck.TabIndex = 9;
            btnCheck.Text = "Check Student";
            btnCheck.UseVisualStyleBackColor = true;
            btnCheck.Click += button1_Click;
            // 
            // btnRegister
            // 
            btnRegister.Location = new Point(350, 279);
            btnRegister.Name = "btnRegister";
            btnRegister.Size = new Size(125, 29);
            btnRegister.TabIndex = 10;
            btnRegister.Text = "Register";
            btnRegister.UseVisualStyleBackColor = true;
            btnRegister.Click += button2_Click;
            // 
            // result
            // 
            result.AutoSize = true;
            result.Location = new Point(86, 360);
            result.Name = "result";
            result.Size = new Size(53, 20);
            result.TabIndex = 11;
            result.Text = "Result ";
            result.Click += label2_Click;
            // 
            // lblResult
            // 
            lblResult.Location = new Point(189, 360);
            lblResult.Name = "lblResult";
            lblResult.Size = new Size(125, 27);
            lblResult.TabIndex = 12;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lblResult);
            Controls.Add(result);
            Controls.Add(btnRegister);
            Controls.Add(btnCheck);
            Controls.Add(txtAge);
            Controls.Add(txtEmail);
            Controls.Add(txtName);
            Controls.Add(txtStudentId);
            Controls.Add(email);
            Controls.Add(age);
            Controls.Add(label3);
            Controls.Add(name);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label name;
        private Label label3;
        private Label age;
        private Label email;
        private TextBox txtStudentId;
        private TextBox txtName;
        private TextBox txtEmail;
        private TextBox txtAge;
        private Button btnCheck;
        private Button btnRegister;
        private Label result;
        private TextBox lblResult;
    }
}
