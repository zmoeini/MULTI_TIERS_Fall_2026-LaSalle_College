create database college
use college


CREATE TABLE Students
(
    StudentId INT PRIMARY KEY,
    Name NVARCHAR(100) NOT NULL,
    Email NVARCHAR(100) NOT NULL,
    Age INT NOT NULL
);
