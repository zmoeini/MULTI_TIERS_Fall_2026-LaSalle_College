﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormDemo
{
    public partial class Login : Form
    {
       
        public Login()
        {
            InitializeComponent();
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {

            // how can read data from form 
            string user = textBoxUserName.Text;
            // you have string and you can not save text in int(ineger)
            string pass =textBoxPassword.Text;

            string connectionString = @"Data Source=DRAGON\MSSQLSERVER01;Initial Catalog=Demo;Integrated Security=True";
            // I can login in form if I have right password and username 

            // Use class SqlConnection to call function for reading address and connect to the database 
            // I need to call function in the class (OOP)

            SqlConnection connection = new SqlConnection(connectionString);
            // open connection 
            try
            {
                connection.Open();
                //MessageBox.Show("Connection is OK");

                // @ it means we have variable in query 
                // I want to write a query then I can use it for so many times

                string query = @"SELECT COUNT(*)
                            FROM users
                            WHERE Username = @user
                            AND Password =@pass ";

                SqlCommand cmd = new SqlCommand(query, connection);

                // SqlCommand will reed our query ?????? you have parameters @user @pass you should explain to me your 
                // parameters
                // 
                cmd.Parameters.AddWithValue("@user", user);
                cmd.Parameters.AddWithValue("@pass", pass);

                // it is time to run the cmd 
                // if I want to return one value cmd.ExecuteScalar()
                // the value from database is text I have int I should Convert it  
                
                int count = Convert.ToInt32(cmd.ExecuteScalar()); 

                // check true or false
                if(count > 0)
                {
                    MessageBox.Show("Login Successful!");
                }
                else
                {
                    MessageBox.Show("Invalid username or password");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection is not  OK" + ex.ToString());

            }
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

    }
}
