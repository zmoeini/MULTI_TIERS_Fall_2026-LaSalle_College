using Microsoft.Data.SqlClient;

namespace StudentRegistration
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCheckStudent_Click(object sender, EventArgs e)
        {
            

        }

        private void buttonRegisterStudent_Click(object sender, EventArgs e)
        {

        }
    }
}
