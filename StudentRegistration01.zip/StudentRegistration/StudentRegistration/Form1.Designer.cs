﻿namespace StudentRegistration
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            buttonCheckStudent = new Button();
            buttonRegisterStudent = new Button();
            textBoxStudentId = new TextBox();
            textBoxName = new TextBox();
            textBoxEmail = new TextBox();
            textBoxAge = new TextBox();
            labelResult = new Label();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(227, 34);
            label1.Name = "label1";
            label1.Size = new Size(92, 21);
            label1.TabIndex = 0;
            label1.Text = "Student ID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(227, 116);
            label2.Name = "label2";
            label2.Size = new Size(57, 21);
            label2.TabIndex = 1;
            label2.Text = "Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(227, 195);
            label3.Name = "label3";
            label3.Size = new Size(52, 21);
            label3.TabIndex = 2;
            label3.Text = "Email:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(227, 271);
            label4.Name = "label4";
            label4.Size = new Size(44, 21);
            label4.TabIndex = 3;
            label4.Text = "Age:";
            // 
            // buttonCheckStudent
            // 
            buttonCheckStudent.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonCheckStudent.Location = new Point(227, 342);
            buttonCheckStudent.Name = "buttonCheckStudent";
            buttonCheckStudent.Size = new Size(98, 63);
            buttonCheckStudent.TabIndex = 4;
            buttonCheckStudent.Text = "Check Student";
            buttonCheckStudent.UseVisualStyleBackColor = true;
            buttonCheckStudent.Click += buttonCheckStudent_Click;
            // 
            // buttonRegisterStudent
            // 
            buttonRegisterStudent.Font = new Font("Segoe UI Semibold", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            buttonRegisterStudent.Location = new Point(371, 342);
            buttonRegisterStudent.Name = "buttonRegisterStudent";
            buttonRegisterStudent.Size = new Size(98, 63);
            buttonRegisterStudent.TabIndex = 5;
            buttonRegisterStudent.Text = "Register Student";
            buttonRegisterStudent.UseVisualStyleBackColor = true;
            buttonRegisterStudent.Click += buttonRegisterStudent_Click;
            // 
            // textBoxStudentId
            // 
            textBoxStudentId.Location = new Point(227, 58);
            textBoxStudentId.Name = "textBoxStudentId";
            textBoxStudentId.Size = new Size(169, 23);
            textBoxStudentId.TabIndex = 6;
            // 
            // textBoxName
            // 
            textBoxName.Location = new Point(227, 140);
            textBoxName.Name = "textBoxName";
            textBoxName.Size = new Size(169, 23);
            textBoxName.TabIndex = 7;
            // 
            // textBoxEmail
            // 
            textBoxEmail.Location = new Point(227, 219);
            textBoxEmail.Name = "textBoxEmail";
            textBoxEmail.Size = new Size(169, 23);
            textBoxEmail.TabIndex = 8;
            // 
            // textBoxAge
            // 
            textBoxAge.Location = new Point(227, 295);
            textBoxAge.Name = "textBoxAge";
            textBoxAge.Size = new Size(169, 23);
            textBoxAge.TabIndex = 9;
            // 
            // labelResult
            // 
            labelResult.AutoSize = true;
            labelResult.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelResult.Location = new Point(227, 433);
            labelResult.Name = "labelResult";
            labelResult.Size = new Size(59, 21);
            labelResult.TabIndex = 10;
            labelResult.Text = "Result:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(818, 558);
            Controls.Add(labelResult);
            Controls.Add(textBoxAge);
            Controls.Add(textBoxEmail);
            Controls.Add(textBoxName);
            Controls.Add(textBoxStudentId);
            Controls.Add(buttonRegisterStudent);
            Controls.Add(buttonCheckStudent);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button buttonCheckStudent;
        private Button buttonRegisterStudent;
        private TextBox textBoxStudentId;
        private TextBox textBoxName;
        private TextBox textBoxEmail;
        private TextBox textBoxAge;
        private Label labelResult;
    }
}
