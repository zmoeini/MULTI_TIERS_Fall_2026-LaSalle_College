﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MultiTiersAssignment1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string studentId = textBoxStudentId.Text;
            
            string name = textBoxName.Text;

            string email = textBoxEmail.Text;

            string age = textBoxAge.Text;

            string connectionString = @"Data Source=ARYAN;Initial Catalog=MutltiTierAssignment1;Integrated Security=True";

            SqlConnection connection = new SqlConnection(connectionString);



            try
            {

                connection.Open();
                MessageBox.Show("Connection is ok");
                string query = @"SELECT COUNT(*)
                                FROM Students
                                WHERE StudentId = @StudentId" ;
                                   

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@StudentId", studentId);

                int count = Convert.ToInt32(cmd.ExecuteScalar());
                if (count > 0)
                {
                    MessageBox.Show("Student is already registered in the college.");
                }
                else
                {
                    MessageBox.Show("Student is not registered in the college");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }


        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
