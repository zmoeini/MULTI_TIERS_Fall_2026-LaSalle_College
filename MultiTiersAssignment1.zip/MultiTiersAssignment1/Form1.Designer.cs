﻿namespace MultiTiersAssignment1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelResult = new System.Windows.Forms.Label();
            this.label1StudentId = new System.Windows.Forms.Label();
            this.label2Name = new System.Windows.Forms.Label();
            this.label3Email = new System.Windows.Forms.Label();
            this.label4Age = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1Check = new System.Windows.Forms.Button();
            this.button2Register = new System.Windows.Forms.Button();
            this.textBoxStudentId = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.textBoxAge = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // labelResult
            // 
            this.labelResult.AutoSize = true;
            this.labelResult.Location = new System.Drawing.Point(415, 253);
            this.labelResult.Name = "labelResult";
            this.labelResult.Size = new System.Drawing.Size(45, 16);
            this.labelResult.TabIndex = 0;
            this.labelResult.Text = "Result";
            this.labelResult.Click += new System.EventHandler(this.label1_Click);
            // 
            // label1StudentId
            // 
            this.label1StudentId.AutoSize = true;
            this.label1StudentId.Location = new System.Drawing.Point(95, 95);
            this.label1StudentId.Name = "label1StudentId";
            this.label1StudentId.Size = new System.Drawing.Size(69, 16);
            this.label1StudentId.TabIndex = 1;
            this.label1StudentId.Text = "StudentId :";
            this.label1StudentId.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // label2Name
            // 
            this.label2Name.AutoSize = true;
            this.label2Name.Location = new System.Drawing.Point(95, 124);
            this.label2Name.Name = "label2Name";
            this.label2Name.Size = new System.Drawing.Size(50, 16);
            this.label2Name.TabIndex = 2;
            this.label2Name.Text = "Name :";
            this.label2Name.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3Email
            // 
            this.label3Email.AutoSize = true;
            this.label3Email.Location = new System.Drawing.Point(95, 154);
            this.label3Email.Name = "label3Email";
            this.label3Email.Size = new System.Drawing.Size(47, 16);
            this.label3Email.TabIndex = 3;
            this.label3Email.Text = "Email :";
            // 
            // label4Age
            // 
            this.label4Age.AutoSize = true;
            this.label4Age.Location = new System.Drawing.Point(95, 182);
            this.label4Age.Name = "label4Age";
            this.label4Age.Size = new System.Drawing.Size(38, 16);
            this.label4Age.TabIndex = 4;
            this.label4Age.Text = "Age :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(95, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 16);
            this.label5.TabIndex = 5;
            // 
            // button1Check
            // 
            this.button1Check.Location = new System.Drawing.Point(129, 250);
            this.button1Check.Name = "button1Check";
            this.button1Check.Size = new System.Drawing.Size(75, 23);
            this.button1Check.TabIndex = 6;
            this.button1Check.Text = "Check";
            this.button1Check.UseVisualStyleBackColor = true;
            // 
            // button2Register
            // 
            this.button2Register.Location = new System.Drawing.Point(277, 250);
            this.button2Register.Name = "button2Register";
            this.button2Register.Size = new System.Drawing.Size(75, 23);
            this.button2Register.TabIndex = 7;
            this.button2Register.Text = "Register";
            this.button2Register.UseVisualStyleBackColor = true;
            this.button2Register.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBoxStudentId
            // 
            this.textBoxStudentId.Location = new System.Drawing.Point(162, 89);
            this.textBoxStudentId.Name = "textBoxStudentId";
            this.textBoxStudentId.Size = new System.Drawing.Size(100, 22);
            this.textBoxStudentId.TabIndex = 8;
            this.textBoxStudentId.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(162, 126);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(100, 22);
            this.textBoxName.TabIndex = 9;
            this.textBoxName.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Location = new System.Drawing.Point(162, 154);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(100, 22);
            this.textBoxEmail.TabIndex = 10;
            // 
            // textBoxAge
            // 
            this.textBoxAge.Location = new System.Drawing.Point(162, 179);
            this.textBoxAge.Name = "textBoxAge";
            this.textBoxAge.Size = new System.Drawing.Size(100, 22);
            this.textBoxAge.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBoxAge);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.textBoxStudentId);
            this.Controls.Add(this.button2Register);
            this.Controls.Add(this.button1Check);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4Age);
            this.Controls.Add(this.label3Email);
            this.Controls.Add(this.label2Name);
            this.Controls.Add(this.label1StudentId);
            this.Controls.Add(this.labelResult);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelResult;
        private System.Windows.Forms.Label label1StudentId;
        private System.Windows.Forms.Label label2Name;
        private System.Windows.Forms.Label label3Email;
        private System.Windows.Forms.Label label4Age;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1Check;
        private System.Windows.Forms.Button button2Register;
        private System.Windows.Forms.TextBox textBoxStudentId;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.TextBox textBoxAge;
    }
}

