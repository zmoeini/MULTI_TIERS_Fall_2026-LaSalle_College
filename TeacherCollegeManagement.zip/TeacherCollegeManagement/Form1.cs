﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TeacherCollegeManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void buttonCheck_Click(object sender, EventArgs e)
        {
            MessageBox.Show("hello");

            int studentId = Convert.ToInt32(textBoxStudentID.Text);
            string connectionString = @"Data Source=DESKTOP-FKU5UIP\MSSQLSERVER2022;Initial Catalog =DemoMulti;Integrated Security=True";

            SqlConnection connection = new SqlConnection(connectionString);
            // Open connection 
            try
            {
                connection.Open();

                //query
                string query = @"SELECT COUNT(*)
                            FROM Students
                            WHERE StudentId = @StudentId ";


                SqlCommand cmd = new SqlCommand(query, connection);

                //  parameter StudentId
                cmd.Parameters.AddWithValue("@StudentId", studentId);



                int count = Convert.ToInt32(cmd.ExecuteScalar());

                // check true or false
                if (count > 0)
                {
                    MessageBox.Show("Student is already registered in the college.");
                }
                else
                {
                    MessageBox.Show("Student is not registered in the college.");
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection is not  OK" + ex.ToString());

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}

