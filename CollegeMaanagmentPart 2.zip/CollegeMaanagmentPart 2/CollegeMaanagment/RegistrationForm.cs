﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeMaanagment
{
    public partial class RegistrationForm : Form

    {
        public RegistrationForm()
        {
            InitializeComponent();
        }

        private void RegistrationForm_Load(object sender, EventArgs e)
        {

        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            string studentId = txtStudentId.Text.Trim();

            if (string.IsNullOrEmpty(studentId))
            {
                MessageBox.Show("Please enter a Student ID.");
                return;
            }

           

            string connectionString = @"Data Source=DEADPOOL;Initial Catalog=Demo;Integrated Security=True";

            SqlConnection connection = new SqlConnection(connectionString);
            try
            {
                connection.Open();

                string query = @"SELECT COUNT(*)
                          FROM Students
                          WHERE StudentId = @StudentId";

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.Add("@StudentId", SqlDbType.Int).Value = studentId;

                int count = Convert.ToInt32(cmd.ExecuteScalar());

                if (count > 0)
                {
                    MessageBox.Show("Student is already registered in the college.");
                }
                else
                {
                    MessageBox.Show("Student is not registered in the college.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Connection is not OK " + ex.ToString());
            }
           

        }
    }
}
