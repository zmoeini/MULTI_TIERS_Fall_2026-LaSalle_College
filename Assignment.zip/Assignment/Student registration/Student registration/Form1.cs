﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Student_registration
{
    public partial class Form1 : Form
    {
        private string connectionString =
            @"Data Source=localhost\SQLEXPRESS;Initial Catalog=Students;Integrated Security=True";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {
            int studentId;

            if (!int.TryParse(txtStudentId.Text, out studentId))
            {
                lblResult.Text = "Please enter a valid Student ID.";
                return;
            }

            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            {
                connection.Open();

                string query = @"
                    SELECT COUNT(*)
                    FROM Students
                    WHERE StudentId = @StudentId";

                using (SqlCommand command =
                       new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue(
                        "@StudentId", studentId);

                    int count = (int)command.ExecuteScalar();

                    if (count > 0)
                    {
                        lblResult.Text =
                            "Student is already registered in the college.";
                    }
                    else
                    {
                        lblResult.Text =
                            "Student is not registered in the college.";
                    }
                }
            }
        }
    }
}