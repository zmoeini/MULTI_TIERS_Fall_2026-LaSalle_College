﻿namespace StudentsRegistrationApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StudentRegistration = new System.Windows.Forms.Label();
            this.StudentID = new System.Windows.Forms.Label();
            this.txtStudentId = new System.Windows.Forms.TextBox();
            this.Name = new System.Windows.Forms.Label();
            this.StudentEmail = new System.Windows.Forms.Label();
            this.StudentAge = new System.Windows.Forms.Label();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.btnCheck = new System.Windows.Forms.Button();
            this.btnRegister = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblResult = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // StudentRegistration
            // 
            this.StudentRegistration.AutoSize = true;
            this.StudentRegistration.Location = new System.Drawing.Point(12, 9);
            this.StudentRegistration.Name = "StudentRegistration";
            this.StudentRegistration.Size = new System.Drawing.Size(103, 13);
            this.StudentRegistration.TabIndex = 0;
            this.StudentRegistration.Text = "Student Registration";
            // 
            // StudentID
            // 
            this.StudentID.AutoSize = true;
            this.StudentID.Location = new System.Drawing.Point(12, 43);
            this.StudentID.Name = "StudentID";
            this.StudentID.Size = new System.Drawing.Size(61, 13);
            this.StudentID.TabIndex = 1;
            this.StudentID.Text = "Student ID:";
            // 
            // txtStudentId
            // 
            this.txtStudentId.Location = new System.Drawing.Point(82, 43);
            this.txtStudentId.Name = "txtStudentId";
            this.txtStudentId.Size = new System.Drawing.Size(183, 20);
            this.txtStudentId.TabIndex = 2;
            // 
            // Name
            // 
            this.Name.AutoSize = true;
            this.Name.Location = new System.Drawing.Point(18, 78);
            this.Name.Name = "Name";
            this.Name.Size = new System.Drawing.Size(38, 13);
            this.Name.TabIndex = 3;
            this.Name.Text = "Name:";
            // 
            // StudentEmail
            // 
            this.StudentEmail.AutoSize = true;
            this.StudentEmail.Location = new System.Drawing.Point(18, 116);
            this.StudentEmail.Name = "StudentEmail";
            this.StudentEmail.Size = new System.Drawing.Size(35, 13);
            this.StudentEmail.TabIndex = 4;
            this.StudentEmail.Text = "Email:";
            this.StudentEmail.Click += new System.EventHandler(this.label2_Click);
            // 
            // StudentAge
            // 
            this.StudentAge.AutoSize = true;
            this.StudentAge.Location = new System.Drawing.Point(18, 157);
            this.StudentAge.Name = "StudentAge";
            this.StudentAge.Size = new System.Drawing.Size(29, 13);
            this.StudentAge.TabIndex = 5;
            this.StudentAge.Text = "Age:";
            this.StudentAge.Click += new System.EventHandler(this.StudentAge_Click);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(82, 78);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(183, 20);
            this.txtName.TabIndex = 6;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(82, 113);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(183, 20);
            this.txtEmail.TabIndex = 7;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(82, 157);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(183, 20);
            this.txtAge.TabIndex = 8;
            // 
            // btnCheck
            // 
            this.btnCheck.Location = new System.Drawing.Point(54, 345);
            this.btnCheck.Name = "btnCheck";
            this.btnCheck.Size = new System.Drawing.Size(118, 37);
            this.btnCheck.TabIndex = 9;
            this.btnCheck.Text = "Check";
            this.btnCheck.UseVisualStyleBackColor = true;
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(264, 345);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(123, 37);
            this.btnRegister.TabIndex = 10;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(272, 353);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 11;
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(21, 264);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(40, 13);
            this.lblResult.TabIndex = 12;
            this.lblResult.Text = "Result:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.btnCheck);
            this.Controls.Add(this.txtAge);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.StudentAge);
            this.Controls.Add(this.StudentEmail);
            this.Controls.Add(this.Name);
            this.Controls.Add(this.txtStudentId);
            this.Controls.Add(this.StudentID);
            this.Controls.Add(this.StudentRegistration);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label StudentRegistration;
        private System.Windows.Forms.Label StudentID;
        private System.Windows.Forms.TextBox txtStudentId;
        private System.Windows.Forms.Label Name;
        private System.Windows.Forms.Label StudentEmail;
        private System.Windows.Forms.Label StudentAge;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.Button btnCheck;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblResult;
    }
}

