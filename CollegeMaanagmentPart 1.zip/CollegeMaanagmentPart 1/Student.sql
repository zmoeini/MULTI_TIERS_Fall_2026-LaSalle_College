use Demo;
CREATE TABLE Students

(

StudentId INT PRIMARY KEY,

Name NVARCHAR(100) NOT NULL,

Email NVARCHAR(100) NOT NULL,

Age INT NOT NULL

);

INSERT INTO Students (StudentId, Name, Email, Age) VALUES (1, 'Emma Johnson', 'emma.johnson@email.com', 21);
INSERT INTO Students (StudentId, Name, Email, Age) VALUES (2, 'Liam Smith', 'liam.smith@email.com', 22);
INSERT INTO Students (StudentId, Name, Email, Age) VALUES (3, 'Olivia Brown', 'olivia.brown@email.com', 20);
INSERT INTO Students (StudentId, Name, Email, Age) VALUES (4, 'Noah Davis', 'noah.davis@email.com', 23);
INSERT INTO Students (StudentId, Name, Email, Age) VALUES (5, 'Ava Wilson', 'ava.wilson@email.com', 19);

select * from Students;