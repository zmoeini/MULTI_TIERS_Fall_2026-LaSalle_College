﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Assigment_
{
    public partial class StudentRegistration : Form
    {
        public StudentRegistration()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string studentId = textBox1.Text;
            string studentName = textBox2.Text;
            string studentEmail = textBox3.Text;
            string studentAge = textBox4.Text;

            string ConnectionString = @"Data Source=localhost\SQLEXPRESS01;Initial Catalog=assSept14;Integrated Security=True";

            SqlConnection connection = new SqlConnection(ConnectionString);

            try
            {
                connection.Open();

                string query = @"SELECT COUNT(*) FROM student WHERE StudentId = @studentId AND studentName = @Name AND studentEmail = @Email AND studentAge = @Age";

                SqlCommand cmd = new SqlCommand(query, connection);

                cmd.Parameters.AddWithValue("@StudentId", studentId);
                cmd.Parameters.AddWithValue("@Name", studentName);
                cmd.Parameters.AddWithValue("@Email", studentEmail);
                cmd.Parameters.AddWithValue("@Age", studentAge);


                int count = Convert.ToInt32(cmd.ExecuteScalar());

                if(count > 0)
                {
                    MessageBox.Show("Student is registered.");
                }
                else
                {
                    MessageBox.Show("Student is not registered!");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("error " + ex.Message);
            }

        }
    }
}
