using System.Data.SqlClient;
namespace Assignment2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnRegster_Click(object sender, EventArgs e)
        {

        }
    }
}
