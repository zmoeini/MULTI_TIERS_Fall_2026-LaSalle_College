﻿namespace Assignment2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            BoxStudent = new TextBox();
            BoxEmail = new TextBox();
            BoxName = new TextBox();
            BoxAge = new TextBox();
            btnRegster = new Button();
            btnCheck = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(54, 88);
            label1.Name = "label1";
            label1.Size = new Size(62, 15);
            label1.TabIndex = 0;
            label1.Text = "StudentID:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(51, 157);
            label2.Name = "label2";
            label2.Size = new Size(42, 15);
            label2.TabIndex = 1;
            label2.Text = "Name:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(54, 185);
            label3.Name = "label3";
            label3.Size = new Size(31, 15);
            label3.TabIndex = 2;
            label3.Text = "Age:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(54, 117);
            label4.Name = "label4";
            label4.Size = new Size(39, 15);
            label4.TabIndex = 3;
            label4.Text = "Email:";
            // 
            // BoxStudent
            // 
            BoxStudent.Location = new Point(138, 85);
            BoxStudent.Name = "BoxStudent";
            BoxStudent.Size = new Size(171, 23);
            BoxStudent.TabIndex = 4;
            // 
            // BoxEmail
            // 
            BoxEmail.Location = new Point(138, 114);
            BoxEmail.Name = "BoxEmail";
            BoxEmail.Size = new Size(171, 23);
            BoxEmail.TabIndex = 5;
            // 
            // BoxName
            // 
            BoxName.Location = new Point(120, 154);
            BoxName.Name = "BoxName";
            BoxName.Size = new Size(171, 23);
            BoxName.TabIndex = 6;
            // 
            // BoxAge
            // 
            BoxAge.Location = new Point(120, 185);
            BoxAge.Name = "BoxAge";
            BoxAge.Size = new Size(171, 23);
            BoxAge.TabIndex = 7;
            // 
            // btnRegster
            // 
            btnRegster.Location = new Point(97, 261);
            btnRegster.Name = "btnRegster";
            btnRegster.Size = new Size(75, 23);
            btnRegster.TabIndex = 8;
            btnRegster.Text = "Register";
            btnRegster.UseVisualStyleBackColor = true;
            btnRegster.Click += btnRegster_Click;
            // 
            // btnCheck
            // 
            btnCheck.Location = new Point(246, 261);
            btnCheck.Name = "btnCheck";
            btnCheck.Size = new Size(75, 23);
            btnCheck.TabIndex = 9;
            btnCheck.Text = "Check";
            btnCheck.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCheck);
            Controls.Add(btnRegster);
            Controls.Add(BoxAge);
            Controls.Add(BoxName);
            Controls.Add(BoxEmail);
            Controls.Add(BoxStudent);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox BoxStudent;
        private TextBox BoxEmail;
        private TextBox BoxName;
        private TextBox BoxAge;
        private Button btnRegster;
        private Button btnCheck;
    }
}
